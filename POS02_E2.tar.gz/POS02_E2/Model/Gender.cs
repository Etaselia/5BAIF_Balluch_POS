﻿namespace LinqUebung1.Application.Model
{
    enum Gender { Female = 1, Male}
}