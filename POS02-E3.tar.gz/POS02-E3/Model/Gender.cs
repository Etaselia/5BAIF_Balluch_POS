﻿namespace POS02_E3.Model
{
    enum Gender { Female = 1, Male}
}