using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RichDomainModelHealthcare.Data;
// Use the correct namespace

namespace RichDomainModelHealthcareApp.Pages.Clinicians;

public class PatientsByClinicianModel : PageModel
{
    private readonly HealthcareContext _context;

    public PatientsByClinicianModel(HealthcareContext context)
    {
        _context = context;
    }

    // Define a ViewModel to represent each group of patients for a clinician
    public class ClinicianPatientsGroup
    {
        public string ClinicianName { get; set; }
        public Guid ClinicianId { get; set; }
        public List<string> PatientNames { get; set; }
    }

    public IList<ClinicianPatientsGroup> ClinicianPatientsGroups { get; set; } = null!;

    public async Task OnGetAsync()
    {
        ClinicianPatientsGroups = await _context.Appointments
            .Include(a => a.Patient)
            .Include(a => a.Clinician)
            .Select(a => new { a.Clinician, a.Patient })
            .GroupBy(ap => ap.Clinician.Id)
            .Select(group => new ClinicianPatientsGroup
            {
                ClinicianId = group.First().Clinician.Id,
                ClinicianName = group.First().Clinician.Name.FirstName + " " + group.First().Clinician.Name.LastName, // Adjust according to your Name structure
                PatientNames = group.Select(g => g.Patient.Name.FirstName + " " + g.Patient.Name.LastName).ToList() // Adjust according to your Name structure
            })
            .ToListAsync();
    }

    public async Task<IActionResult> OnPostDeleteAsync(Guid id)
    {
        var clinician = await _context.Clinicians.FindAsync(id);
        if (clinician == null)
        {
            return NotFound();
        }

        // Unassign patients by deleting appointments associated with the clinician
        var appointments = await _context.Appointments
            .Where(a => a.ClinicianId == id)
            .ToListAsync();

        _context.Appointments.RemoveRange(appointments);

        // Now delete the clinician
        _context.Clinicians.Remove(clinician);
    
        await _context.SaveChangesAsync();

        return RedirectToPage();
    }
}